package model;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import controller.StateController;

/**
 * Servlet implementation class SockAPI
 */
@WebServlet
public class SockAPI extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final String urlSock = "/MessagingMonitor/api/v0/websock/addr";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SockAPI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("WebSocket is configured to: "+StateController.sockAddr);
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    StringBuilder buffer = new StringBuilder();
	    BufferedReader reader = request.getReader();
	    String line;
	    while ((line = reader.readLine()) != null) {
	        buffer.append(line);
	        buffer.append(System.lineSeparator());
	    }
	    String data = buffer.toString();
		if(request.getRequestURI().equals(urlSock)) {
			StateController.sockAddr = new String(data.getBytes(), StandardCharsets.UTF_8).replaceAll("\\s{2,}", "");
		}
		else {
			response.getWriter().append("[x] This socket does not exist.");
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		doGet(request, response);
	}

}
