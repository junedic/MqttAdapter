package model;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import controller.StateController;

/**
 * Servlet implementation class ServerAPI
 */
@WebServlet
public class ServerAPI extends HttpServlet {
	
	private static final String urlServA 	= "/MessagingMonitor/api/v0/mqtt/server/one";
	private static final String urlServB 	= "/MessagingMonitor/api/v0/mqtt/server/two";
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServerAPI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Servers are configured to A: "+StateController.serverA+" & B: "+StateController.serverB);
	}

	/**
	 * @see HttpServlet#doPut(HttpServletRequest, HttpServletResponse)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    StringBuilder buffer = new StringBuilder();
	    BufferedReader reader = request.getReader();
	    String line;
	    while ((line = reader.readLine()) != null) {
	        buffer.append(line);
	        buffer.append(System.lineSeparator());
	    }
	    String data = buffer.toString();
		if(request.getRequestURI().equals(urlServA)) {
			StateController.serverA = new String(data.getBytes(), StandardCharsets.UTF_8).replaceAll("\\s{2,}", "");
		}
		else if(request.getRequestURI().equals(urlServB)) {
			StateController.serverB = new String(data.getBytes(), StandardCharsets.UTF_8).replaceAll("\\s{2,}", "");
		}
		else {
			response.getWriter().append("[x] This server does not exist.");
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		doGet(request, response);
	}

}
