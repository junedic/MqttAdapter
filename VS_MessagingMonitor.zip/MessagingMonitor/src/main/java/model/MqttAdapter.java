package model;

import org.eclipse.paho.mqttv5.client.*;
import org.eclipse.paho.mqttv5.client.persist.MemoryPersistence;
import org.eclipse.paho.mqttv5.common.MqttException;
import org.eclipse.paho.mqttv5.common.MqttMessage;
import org.eclipse.paho.mqttv5.common.packet.MqttProperties;
import org.json.*;

import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

import controller.StateController;

import javax.servlet.http.HttpServlet;
import jakarta.websocket.*;
import jakarta.websocket.server.ServerEndpoint;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.SyslogMessage;
import model.SyslogMessage.Severity;

@ServerEndpoint("/websocket")
public class MqttAdapter extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
    private MqttAsyncClient mqttClientA;
    private MqttAsyncClient mqttClientB;
    private static volatile Session websocketSession;

    public MqttAdapter() {
    	super();
    }
    
    @OnOpen
    public void open(Session session) {
    	websocketSession = session;
    }
    
	@OnError
	public void error(Throwable t) {
		System.out.println("Generic error");
		t.printStackTrace();
	}
    
    @OnClose
    public void close(Session session) {
    	try {
    		if(!websocketSession.isOpen()) {
				websocketSession.close();
    		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

    public void connect() throws MqttException, Exception {
        MemoryPersistence persistence = new MemoryPersistence();
        mqttClientA = new MqttAsyncClient(StateController.serverA, "1", persistence);
        if(!StateController.serverA.equals(StateController.serverB) && !StateController.serverB.equals(""))
        	mqttClientB = new MqttAsyncClient(StateController.serverB, "1", persistence);
        MqttCallback cb = new MqttCallback() {
        	
        	private ArrayList<String> minSev = new ArrayList<>();

			@Override
            public void disconnected(MqttDisconnectResponse disResp) {
                // Reconnect to MQTT broker
                try {
                    connectToBroker();
                    subscribeToTopics();
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) {
            	byte[] payload = message.getPayload();
            	String msg = new String(payload);
            	Pattern sev = Pattern.compile("(?<=sev:)(.*)(?=,host)");
            	Matcher sevmatcher = sev.matcher(msg);
				try {
	                if (sevmatcher.find() && this.minSev.contains(sevmatcher.group())) {
	                        websocketSession.getBasicRemote().sendText(msg);
	                }
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }


			@Override
			public void authPacketArrived(int arg0, MqttProperties arg1) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void connectComplete(boolean arg0, String arg1) {
				// TODO Auto-generated method stub
		        minSev.add(Severity.EMERGENCY.toString());
		        minSev.add(Severity.ALERT.toString());
		        minSev.add(Severity.CRITICAL.toString());
		        minSev.add(Severity.ERROR.toString());
		        minSev.add(Severity.WARNING.toString());
			}

			@Override
			public void deliveryComplete(IMqttToken arg0) {
				// TODO Auto-generated method stub
				
			}


			@Override
			public void mqttErrorOccurred(MqttException arg0) {
				// TODO Auto-generated method stub
				
			}
        };
        
        mqttClientA.setCallback(cb);
        if(!StateController.serverA.equals(StateController.serverB) && !StateController.serverB.equals(""))
        	mqttClientB.setCallback(cb);

        connectToBroker();
        subscribeToTopics();
    }

    private void connectToBroker() throws MqttException {
    	IMqttToken tokenA = mqttClientA.connect();
    	if(!StateController.serverA.equals(StateController.serverB) && !StateController.serverB.equals("")) {
    		IMqttToken tokenB = mqttClientB.connect();
    		tokenB.waitForCompletion();
    	}
    	tokenA.waitForCompletion();
    }

    private void subscribeToTopics() throws MqttException {
        mqttClientA.subscribe(StateController.topicA, 1);
        if(!StateController.serverA.equals(StateController.serverB) && !StateController.serverB.equals(""))
        	mqttClientB.subscribe(StateController.topicB, 1);
    }

    private Object deserializeObject(byte[] bytes) throws Exception {
        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ObjectInputStream in = new ObjectInputStream(bis);
        return in.readObject();
    }

}

