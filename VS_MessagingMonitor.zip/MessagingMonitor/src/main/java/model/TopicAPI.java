package model;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import controller.StateController;

/**
 * Servlet implementation class TopicAPI
 */
@WebServlet
public class TopicAPI extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final String urlTopA = "/MessagingMonitor/api/v0/mqtt/topic/one";
	private static final String urlTopB = "/MessagingMonitor/api/v0/mqtt/topic/two";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TopicAPI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Topics are configured to A: "+StateController.topicA+" & B: "+StateController.topicB);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    StringBuilder buffer = new StringBuilder();
	    BufferedReader reader = request.getReader();
	    String line;
	    while ((line = reader.readLine()) != null) {
	        buffer.append(line);
	        buffer.append(System.lineSeparator());
	    }
	    String data = buffer.toString();
		if(request.getRequestURI().equals(urlTopA)) {
			StateController.topicA = new String(data.getBytes(), StandardCharsets.UTF_8).replaceAll("\\s{2,}", "");
		}
		else if(request.getRequestURI().equals(urlTopB)) {
			StateController.topicB = new String(data.getBytes(), StandardCharsets.UTF_8).replaceAll("\\s{2,}", "");
		}
		else {
			response.getWriter().append("[x] This topic does not exist.");
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		doGet(request, response);
		doGet(request, response);
	}

}
