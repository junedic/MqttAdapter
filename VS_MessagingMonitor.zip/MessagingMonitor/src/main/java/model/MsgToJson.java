package model;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

public class MsgToJson {

	public static void main(String[] args) {
        SyslogMessage s = new SyslogMessage(SyslogMessage.Facility.KERNEL, SyslogMessage.Severity.WARNING,
                new AsciiChars.L255("host"), new AsciiChars.L048("appName"), new AsciiChars.L128("procId"),
                new AsciiChars.L032("msgId"), null, new SyslogMessage.TextMessage("alo bre alo bre"));
        Gson gson = new Gson();
        System.out.println(gson.toJson(s));
        
	}

}
