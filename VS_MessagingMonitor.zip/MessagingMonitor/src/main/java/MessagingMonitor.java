import java.io.IOException;
import java.nio.file.FileSystems;

import controller.StateController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.FileReader;
import model.MqttAdapter;

@WebServlet
public class MessagingMonitor extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final String index = "<!DOCTYPE html>\r\n"
			+ "<html>\r\n"
			+ "<head>\r\n"
			+ "<meta charset=\"ISO-8859-1\">\r\n"
			+ "<title>MessagingMonitor</title>\r\n"
			+ "<link rel=\"stylesheet\" \r\n"
			+ "      href=\r\n"
			+ "\"https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css\"/>\r\n"
			+ "\r\n"
			+ "<script>\r\n"
			+ "		let url = %s ;\r\n"
			+ "		let socket = new WebSocket(url);\r\n"
			+ "		socket.onopen = async (message) => console.log('CONNECTED', message);\r\n"
			+ "		socket.onmessage = function(message) {\r\n"
			+ "		 	document.getElementById(\"logmsg\").innerHTML += \"<li>\" + message.data + \"</li>\";\r\n"
			+ "			document.getElementById(\"logmsg\").innerHTML += \"<li>\" + JSON.parse(message.data).text + \"</li>\";\r\n"
			+ "		};\r\n"
			+ "		socket.onclose = (message) => console.log('CLOSE', message);\r\n"
			+ "		socket.onerror = (ex) => console.log('ERROR', ex);\r\n"
			+ "		window.onunload = function() { socket.close(); }\r\n"
			+ "</script>\r\n"
			+ "</head>\r\n"
			+ "<body>\r\n"
			+ "	<div style=\"display: flex; flex-direction: row; height: 100vh; width: 100vw;\">\r\n"
			+ "		<div style=\"width: 15vw; padding-top: 5vh; padding-left: 2vw;\">\r\n"
			+ "			<h1>API-Endpoints</h1>\r\n"
			+ "			PUT /api/v0/mqtt/server/one<br/>\r\n"
			+ "			PUT /api/v0/mqtt/server/two<br/>\r\n"
			+ "			PUT /api/v0/mqtt/topic/one<br/>\r\n"
			+ "			PUT /api/v0/mqtt/topic/two<br/>\r\n"
			+ "			PUT /api/v0/websock/addr<br/>\r\n"
			+ "			\r\n"
			+ "			<h1>Server</h1>\r\n"
			+ "			<h2>Parameters</h2>\r\n"
			+ "			MqttServer One: %s<br/>\r\n"
			+ "			MqttServer Two: %s<br/>\r\n"
			+ "			Topic One: %s<br/>\r\n"
			+ "			Topic Two: %s<br/>\r\n"
			+ "			WebsockAddr: %s<br/>\r\n"
			+ "			\r\n"
			+ "			<h2>Runtime</h2>\r\n"
			+ "			Status: %s<p/>\r\n"
			+ "			<form action=\"\" method=\"post\">"	
			+ "				<button>Start</button>\r\n"
			+"			</form>"		
			+ "		</div>\r\n"
			+ "		<div style=\"display: flex; flex-direction: column; align-items: center; width: 77vw; height: 95vh; padding-top: 5vh; padding-left: 3vw; border-left: 1px solid black;\">\r\n"
			+ "			<h1>Log Messages</h1>\r\n"
			+ "			<p/>\r\n"
			+ "			<div id=\"logmsg\" style=\"width: 77vw; height: 76vh; overflow-y: scroll; overflow-x: hidden; overflow-wrap: break-word; border-top: 2px dashed black; border-bottom: 2px dashed black; border-left: 2px dashed black;\">\r\n"
			+ "			\r\n"
			+ "			</div>\r\n"
			+ "		</div>\r\n"
			+ "	</div>\r\n"
			+ "</body>\r\n"
			+ "</html>";
	
	private MqttAdapter mqtt;
	
	public MessagingMonitor() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String dynIndex = String.format(index, "'ws://localhost:11504/MessagingMonitor/websocket'", StateController.serverA, StateController.serverB, StateController.topicA, StateController.topicB, StateController.sockAddr, (StateController.status.get()) ? "running" : "not running");
		response.getWriter().append(dynIndex);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			mqtt = new MqttAdapter();
			mqtt.connect();
			StateController.status.set(true);
		} catch (Exception e) { e.printStackTrace(); }
		doGet(request, response);
	}
}