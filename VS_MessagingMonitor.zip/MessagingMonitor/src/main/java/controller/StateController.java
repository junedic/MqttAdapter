package controller;

import java.util.concurrent.atomic.AtomicBoolean;

public class StateController {
	
	public static final AtomicBoolean status = new AtomicBoolean(false);
	public static String serverA = "";
	public static String serverB = "";
	public static String topicA = "";
	public static String topicB = "";
	public static String sockAddr = "";

}
